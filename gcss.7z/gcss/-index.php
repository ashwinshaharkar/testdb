<?php

require_once 'vendor/autoload.php';
session_start();
// $client = new Google_Client();
// $client->setApplicationName("Client_Library_Examples");
// $client->setDeveloperKey("AIzaSyBWseTr0NQoxthxnC-4wCiKcHF-FhEYfbE");

// $service = new Google_Service_Books($client);
// $optParams = array('filter' => 'free-ebooks');
// $results = $service->volumes->listVolumes('Henry David Thoreau', $optParams);

// foreach ($results as $item) {
//   echo $item['volumeInfo']['title'], "<br /> \n";
// }


    $client_id = '43212426181-1g65j41m17r5418ugr707qun3u66gtfv.apps.googleusercontent.com';
    $Email_address = 'ashwin.shaharkar@gmail.com';     
    $key_file_location = 'D:/xampp/htdocs/gcss/client_secret_43212426181-1g65j41m17r5418ugr707qun3u66gtfv.apps.googleusercontent.com.json';      

    $client = new Google_Client();      
    $client->setApplicationName("Client_Library_Examples");
    $key = file_get_contents($key_file_location);    

    // seproate additional scopes with a comma   
    $scopes ="https://www.googleapis.com/auth/analytics.readonly";  

    $cred = new Google_Auth_AssertionCredentials($Email_address,array($scopes),$key);     

    $client->setAssertionCredentials($cred);
    if($client->getAuth()->isAccessTokenExpired()) {        
         $client->getAuth()->refreshTokenWithAssertion($cred);      
    }       

    $service = new Google_Service_Analytics($client);



    //Adding Dimensions
    $params = array('dimensions' => 'ga:userType'); 
    // requesting the data  
    $data = $service->data_ga->get("ga:89798036", "2014-12-14", "2014-12-14", "ga:users,ga:sessions", $params );     
?>

<html>   
Results for date:  2014-12-14<br>
    <table border="1">   
        <tr>     
        <?php    
        //Printing column headers
        foreach($data->getColumnHeaders() as $header){
             print "<td><b>".$header['name']."</b></td>";       
            }       
        ?>      
        </tr>       
        <?php       
        //printing each row.
        foreach ($data->getRows() as $row) {        
            print "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td></tr>";   
        }    
?>      
<tr><td colspan="2">Rows Returned <?php print $data->getTotalResults();?> </td></tr>     
</table>     
</html>     

<?php


// $client = new Google_Client();
// $client->setAuthConfig('client_secret_43212426181-1g65j41m17r5418ugr707qun3u66gtfv.apps.googleusercontent.com.json');
// $client->setAccessType("offline");        // offline access
// $client->setIncludeGrantedScopes(true);   // incremental auth
// $client->setApplicationName('Content API for Shopping Samples');
// $client->setScopes(Google_Service_ShoppingContent::CONTENT);
// //$client->setRedirectUri('http://' . $_SERVER['HTTP_HOST'] . '/oauth2callback.php');


// $service = new Google_Service_ShoppingContent($client);
// $products = $service->products->listProducts('124020921');
// $parameters = array();
// while (!empty($products->getResources())) {
//   foreach ($products->getResources() as $product) {
//     printf("%s %s\n", $product->getId(), $product->getTitle());
//   }
//   if (!empty($products->getNextPageToken())) {
//     break;
//   }
//   $parameters['pageToken'] = $products->nextPageToken;
//   $products = $service->products->listProducts($merchantId, $parameters);
// }
?>
echo "here"; die;

